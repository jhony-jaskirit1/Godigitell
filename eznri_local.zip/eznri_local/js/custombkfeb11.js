var site_path='/';jQuery(document).ready(function($){jQuery(window).load(function() {jQuery(".loading").hide();});jQuery('.animated').appear();jQuery(document.body).on('appear','.fade',function(){jQuery(this).each(function(){jQuery(this).addClass('anim-fade')});});jQuery(document.body).on('appear','.slidea',function(){jQuery(this).each(function(){jQuery(this).addClass('anim-slide')});});jQuery(document.body).on('appear','.hatch',function(){jQuery(this).each(function(){jQuery(this).addClass('anim-hatch')});});jQuery(document.body).on('appear','.entrance',function(){jQuery(this).each(function(){jQuery(this).addClass('anim-entrance')});});jQuery(document.body).on('appear','.fadeInUpNow',function(){jQuery(this).each(function(){jQuery(this).addClass('fadeInUp')});});jQuery(document.body).on('appear','.fadeInDownNow',function(){jQuery(this).each(function(){jQuery(this).addClass('fadeInDown')});});jQuery(document.body).on('appear','.fadeInLeftNow',function(){jQuery(this).each(function(){jQuery(this).addClass('fadeInLeft')});});jQuery(document.body).on('appear','.fadeInRightNow',function(){jQuery(this).each(function(){jQuery(this).addClass('fadeInRight')});});jQuery(document.body).on('appear','.fadeInUpBigNow',function(){jQuery(this).each(function(){jQuery(this).addClass('fadeInUpBig')});});jQuery(document.body).on('appear','.fadeInDownBigNow',function(){jQuery(this).each(function(){jQuery(this).addClass('fadeInDownBig')});});jQuery(document.body).on('appear','.fadeInLeftBigNow',function(){jQuery(this).each(function(){jQuery(this).addClass('fadeInLeftBig')});});jQuery(document.body).on('appear','.fadeInRightBigNow',function(){jQuery(this).each(function(){jQuery(this).addClass('fadeInRightBig')});});jQuery(document.body).on('appear','.fadeInNow',function(){jQuery(this).each(function(){jQuery(this).addClass('fadeIn')});});jQuery(document.body).on('appear','.flashNow',function(){jQuery(this).each(function(){jQuery(this).addClass('flash')});});jQuery(document.body).on('appear','.shakeNow',function(){jQuery(this).each(function(){jQuery(this).addClass('shake')});});jQuery(document.body).on('appear','.bounceNow',function(){jQuery(this).each(function(){jQuery(this).addClass('bounce')});});jQuery(document.body).on('appear','.bounceInNow',function(){jQuery(this).each(function(){jQuery(this).addClass('bounceIn')});});jQuery(document.body).on('appear','.tadaNow',function(){jQuery(this).each(function(){jQuery(this).addClass('tada')});});jQuery(document.body).on('appear','.swingNow',function(){jQuery(this).each(function(){jQuery(this).addClass('swing')});});jQuery(document.body).on('appear','.flipInYNow',function(){jQuery(this).each(function(){jQuery(this).addClass('flipInY')});});jQuery(document.body).on('appear','.rotateInNow',function(){jQuery(this).each(function(){jQuery(this).addClass('rotateIn')});});jQuery('.close').click(function(){jQuery('#news-popup .modal-body').html("");});});jQuery(window).load(function(){if(jQuery(window).width()==1024){jQuery(".home-blog-sec .bg-white h5.text-red a").text(function(index,text){return text.substr(0,22);});jQuery(".home-blog-sec .bg-white p").text(function(index,text){return text.substr(0,55);});}
else{jQuery(".home-blog-sec .bg-white h5.text-red a").text(function(index,text){return text.substr(0,40);});jQuery(".home-blog-sec .bg-white p").text(function(index,text){return text.substr(0,75);});}});jQuery(".career-item .career-sm").each(function(index){jQuery(this).on('click','.plusminus',function(){if(!jQuery(this).hasClass('active')){jQuery(".career-item .career-sm").find('.plusminus').eq(index).addClass('active');if(jQuery(this).hasClass('active')){jQuery(".career-item .career-sm").find('.panel-pop').eq(index).slideDown();}}else{jQuery(".career-item .career-sm").find('.plusminus').eq(index).removeClass('active');jQuery(".career-item .career-sm").find('.panel-pop').eq(index).slideUp();}});});jQuery(function(){var checkDeviceOrBrowser=/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);if(checkDeviceOrBrowser){jQuery('.wrapper,.main').bind('touchstart',function(){jQuery('body').removeClass('mobile-side-menu-in');jQuery('.mobile-side-menu').removeClass('slideLeftAnimate');});jQuery(window).scroll(function(){if(jQuery(document).scrollTop()>=100){setTimeout(function(){wistiaEmbed.pause();},200)}});}
else{var winH=jQuery(window).height()-60;var winW=jQuery(window).width()-80;jQuery(".fxslider-full").css("width",winW);jQuery("#wistia-sec").css("height",winH);}
var ua=navigator.userAgent;if(ua.indexOf("Android")>=0)
{var androidversion=parseFloat(ua.slice(ua.indexOf("Android")+8));if(androidversion>=4.2)
{jQuery("#logo").css("position","absolute");jQuery(".navSec").css("position","absolute");}}});jQuery(document).ready(function($){localaddress();jQuery(window).resize(function(){setTimeout(function(){if(jQuery(window).width()==1024){jQuery(".home-blog-sec .bg-white h5.text-red a").text(function(index,text){return text.substr(0,22);});jQuery(".home-blog-sec .bg-white p").text(function(index,text){return text.substr(0,55);});}
else{jQuery(".home-blog-sec .bg-white h5.text-red a").text(function(index,text){return text.substr(0,40);});jQuery(".home-blog-sec .bg-white p").text(function(index,text){return text.substr(0,75);});}},500);});jQuery(window).bind('orientationchange',function(){jQuery("#port-details-content").flexslider(0);});jQuery(window).resize(function(){setTimeout(function(){if(jQuery(window).width()==1024){jQuery('body').removeClass('mobile-side-menu-in');jQuery('#mobile-side-menu').removeClass('slideLeftAnimate');}},300);});jQuery(".mobileMenuIcon").on("click",function(){jQuery('body').toggleClass('mobile-side-menu-in');jQuery('.mobile-side-menu').toggleClass('slideLeftAnimate');jQuery("#show-switch").fadeToggle();});jQuery("#hide-switch, #show-switch").on("click",function(){if(jQuery("#show-switch").is(":visible")){var switchmenu="#show-switch";jQuery("#switch-thumb").animate({"margin-left":"0px"},300).show();jQuery("body").addClass("switch-side-menu-in");}else{var switchmenu="#switch-thumb";jQuery("#show-switch").show().animate({"margin-left":"0"},300);jQuery("body").removeClass("switch-side-menu-in");}
jQuery(switchmenu).animate({"margin-left":"-300px"},300,function(){jQuery(this).hide();});});jQuery('.get-in-touch').on('click',function(){jQuery.when(jQuery(".show-footer").slideDown(300)).done(function(){jQuery(".show-footer").fadeOut(500),jQuery("html,body").animate({scrollTop:jQuery(document).height()},500);jQuery(".load-footer").load(site_path+"footer1.html",function(){jQuery(".bottom-address .posi-r").css({"opacity":"0","height":"150px"});jQuery(".bottom-address").addClass("loadIcon");localaddress();});});});jQuery('[placeholder]').focus(function(){var input=jQuery(this);if(input.val()==input.attr('placeholder')){input.val('');input.removeClass('placeholder');}
if(input.attr('old_type')=='password'){input.attr("type",'password');}}).blur(function(){var input=jQuery(this);if(input.attr('type')=='password'){input.attr("old_type",'password');input.attr("type",'text');}
if(input.val()==''||input.val()==input.attr('placeholder')){input.addClass('placeholder');input.val(input.attr('placeholder'));}
else if(input.attr('old_type')=='password'){input.attr("type",'password');}}).blur();jQuery('[placeholder]').parents('form').submit(function(){jQuery(this).find('[placeholder]').each(function(){var input=jQuery(this);if(input.val()==input.attr('placeholder')){input.val('');}})});});function localaddress(){var ipaddress=jQuery("#ipaddress").val();$.ajax('https://https-api.ipaddresslabs.com/iplocation/v1.7/locateip?key=SAK47HN7664E48XX8P8Z&ip='+ipaddress+'&format=JSON',{dataType:'jsonp',crossDomain:true,success:function(data){curcity=data.geolocation_data.city;couName=data.geolocation_data.country_name;var slider=jQuery('.bx-footer').bxSlider({infiniteLoop:false,hideControlOnEnd:true,auto:false,autoControls:true,pager:false,adaptiveHeight:true,onSliderLoad:function(){setTimeout(function(){switch(couName){case'India':if(curcity=="Chennai"){curAddNo=1;}
else if(curcity=="Bangalore"){curAddNo=2;}
else if(curcity=="Mumbai"){curAddNo=3;}
else if(curcity=="New Delhi"){curAddNo=4;}
else{curAddNo=1;}
break;case'Singapore':if(curcity=="Singapore"){curAddNo=0;}
break;case'United Arab Emirates':if(curcity=="Dubai"){curAddNo=5;}
break;case'United Kingdom':if(curcity=="United Kingdom"){curAddNo=6;}
break;case'United States':if(curcity=="New York"){curAddNo=7;}else if(curcity=="Chicago"){curAddNo=8;}else if(curcity=="San Francisco"){curAddNo=9;}else{curAddNo=7;}
break;default:curAddNo=0;break;}
slider.goToSlide(curAddNo);},500);setTimeout(function(){jQuery(".bottom-address .posi-r").css({"opacity":"1","height":""});jQuery(".bottom-address").removeClass("loadIcon");},2000)}});}});}
function trim(sStr){var s;sStr=sStr.toString();sStr=sStr.replace(/(^\s*)|(\s*$)/g,"");sStr=sStr.replace(/\s{2,}/g," ");return(sStr);}
function validate_phone(phone){var reg=/^[0-9-. +]+$/;if(reg.test(phone)){return true;}else{return false;}}
function validateFeedback(form_type){if(form_type=="contact"){var name=jQuery("#name").val();var email=jQuery("#email").val();var comments=jQuery("#comments").val();var from="Contact";var why2="";$("#name").on("keypress",function(e){if(e.which===32&&!this.value.length)
e.preventDefault();});if(trim(document.getElementById('name').value)==""||document.getElementById('name').value=="Your name"){document.getElementById('name').style.border="1px #FF0000 solid";why2++;}
else{document.getElementById('name').style.border="";}
if(trim(document.getElementById('email').value)==""||document.getElementById('name').value=="Your email"){document.getElementById('email').style.border="1px #FF0000 solid";why2++;}
else{if(!validate_email(document.getElementById('email').value)){document.getElementById('email').style.border="1px #FF0000 solid";why2++;}
else{document.getElementById('email').style.border="";}}
if(comments=='Your comments'){comments='';}
if(why2==""){jQuery('.contactusform').css("display","none");jQuery(".load-icon-foot").addClass("loadIcon");var data={'name':name,'email':email,'comments':comments,'is_from':from};jQuery.post(site_path+"postfrm.php",data,function(r){jQuery(".load-icon-foot").removeClass("loadIcon");jQuery(".contactusthanks").css("display","block");setTimeout(function(){jQuery(".contactusthanks").css("display","none");jQuery(".contactusform").css("display","block");reset();},10000);});jQuery("#name").val("Your name");jQuery("#email").val("Your email");jQuery("#comments").val("Your comments");return false;}
else return false;}
if(form_type=="reach"){var name=jQuery("#reach_name").val();var email=jQuery("#reach_email").val();var comments=jQuery("#reach_comments").val();var from="Reach";var why2="";if(trim(document.getElementById('reach_name').value)==""||document.getElementById('reach_name').value=="Name*"){document.getElementById('reach_name').style.border="1px #FF0000 solid";why2++;}
else{document.getElementById('reach_name').style.border="";}
if(trim(document.getElementById('reach_email').value)==""||document.getElementById('reach_email').value=="Email*"){document.getElementById('reach_email').style.border="1px #FF0000 solid";why2++;}
else{if(!validate_email(document.getElementById('reach_email').value)){document.getElementById('reach_email').style.border="1px #FF0000 solid";why2++;}
else{document.getElementById('reach_email').style.border="";}}
if(comments=='I like to inquire about'){comments='';}
if(why2==""){jQuery('.reachform').css("display","none");jQuery(".load-icon-reach").addClass("loadIcon-white");var data={'name':name,'email':email,'comments':comments,'is_from':from};jQuery.post(site_path+"postfrm.php",data,function(r){jQuery(".load-icon-reach").removeClass("loadIcon-white");jQuery(".reachthanks").css("display","block");setTimeout(function(){jQuery(".reachform").css("display","block");jQuery(".reachthanks").css("display","none");reset();jQuery("#reach_name,#reach_email,#reach_comments").focus();},10000);});jQuery("#reach_name").val("Name*");jQuery("#reach_email").val("Email*");jQuery("#reach_comments").val("I'd like to inquire about");return false;}
else return false;}}
function validateDataStudyForm()
{var firstname=jQuery("#firstname").val();var lastname=jQuery("#lastname").val();var email=jQuery("#email").val();var company=jQuery("#company").val();var why2="";if(trim(document.getElementById('firstname').value)=="First Name*"||trim(document.getElementById('firstname').value)=="")
{document.getElementById('firstname').style.border="1px #FF0000 solid";why2++;}
else
{if(!isAliasName(document.getElementById('firstname').value))
{document.getElementById('firstname').style.border="1px #FF0000 solid";why2++;}
else if(document.getElementById('firstname').value.length>25)
{document.getElementById('firstname').style.border="1px #FF0000 solid";why2++;}
else
{document.getElementById('firstname').style.border="";}}
if(trim(document.getElementById('lastname').value)=="Last Name*"||trim(document.getElementById('lastname').value)=="")
{document.getElementById('lastname').style.border="1px #FF0000 solid";why2++;}
else
{if(!isAliasName(document.getElementById('lastname').value))
{document.getElementById('lastname').style.border="1px #FF0000 solid";why2++;}
else if(document.getElementById('lastname').value.length>25)
{document.getElementById('lastname').style.border="1px #FF0000 solid";why2++;}
else
{document.getElementById('lastname').style.border="";}}
if(trim(document.getElementById('email').value)=="Email*"||trim(document.getElementById('email').value)=="")
{document.getElementById('email').style.border="1px #FF0000 solid";why2++;}
else
{if(!validate_email(document.getElementById('email').value))
{document.getElementById('email').style.border="1px #FF0000 solid";why2++;}
else
{document.getElementById('email').style.border="";}}
if(trim(document.getElementById('company').value)=="Company*"||trim(document.getElementById('company').value)=="")
{document.getElementById('company').style.border="1px #FF0000 solid";why2++;}
else
{document.getElementById('company').style.border="";}
if(why2==""){jQuery("#datastudyform").css("display","none");jQuery("#datastudyformbutton").css("display","none");jQuery(".datastudyform-sec").addClass("loadIcon-white");var firstname=jQuery("#firstname").val();var lastname=jQuery("#lastname").val();var email=jQuery("#email").val();var company=jQuery("#company").val();var data={'firstname':firstname,'email':email,'lastname':lastname,'company':company};$.post("postfrm_datastudy.php",data,function(r,status){jQuery(".datastudyform-sec").removeClass("loadIcon-white");jQuery(".datastudythank").css("display","block");setTimeout(function(){jQuery("#datastudyform").css("display","block");jQuery("#datastudyformbutton").css("display","block");jQuery(".datastudythank").css("display","none");},10000);});jQuery("#firstname").val("First Name*");jQuery("#lastname").val("Last Name*");jQuery("#email").val("Email*");jQuery("#company").val("Company*");return false;}else return false;}
function trim(sStr)
{var s;sStr=sStr.toString();sStr=sStr.replace(/(^\s*)|(\s*$)/g,"");sStr=sStr.replace(/\,}s{2,}/g," ");return(sStr);}
function isAliasName(aliasName)
{var check=/^([a-zA-Z0-9\-\_\ ]+)$/;return check.test(aliasName);}
function validate_email(emailid){var reg=/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;if(reg.test(emailid)==false){return false;}else{return true;}}

jQuery(document).ready(function(){var checkDeviceOrBrowser=/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);menuHighlight();jQuery(window).scroll(function(){if(jQuery(document).scrollTop()>=1){jQuery("#logo").stop().animate({marginTop:"-120px"},300,'swing');jQuery(".iconMenuSec").stop().animate({marginTop:"0px"},300,'swing');jQuery(".navSec").stop().animate({top:"-5px"},300,'swing');}
else if(jQuery(document).scrollTop()<=1){jQuery(".iconMenuSec").stop().animate({marginTop:"-80px"},100,'swing');jQuery("#logo").stop().animate({marginTop:"0px"},300,'swing');jQuery(".navSec").stop().animate({top:"5px"},300,'swing');}});if(checkDeviceOrBrowser){var deviceAgent=navigator.userAgent.toLowerCase();var agentID=deviceAgent.match(/(ipad)/);if(agentID){if(jQuery(window).width()>jQuery(window).height()){jQuery(".homeNav").click(function(){jQuery("ul.subLevel").css("display","none");jQuery(".mainNav li").find("div").css("display","block");jQuery(".mainNav li").find("ul").stop().animate({marginTop:"0px"},300,'swing');jQuery(".outsideNavMain a,.insideNav a,.contactNav a").addClass("active");jQuery("ul.homeLevel .insideNav,ul.homeLevel .outsideNav,ul.homeLevel .contactNav").css("display","inline");jQuery(".homeLevel .insideNav").stop().animate({width:"187px"},300,'swing');jQuery(".homeLevel .outsideNavMain").stop().animate({width:"506px"},300,'swing');jQuery(this).find(".home").addClass("active");});}
else if(jQuery(window).height()>jQuery(window).width()){jQuery(".hservices li h5 a").attr("href","javascript:;");}}}
else{jQuery(".mainNav li div").hover(function(){jQuery(this).prev("a").addClass("active");},function(){jQuery(this).prev("a").removeClass("active");});jQuery(".mainNav li").hover(function(){jQuery(this).find("div").css("display","block");jQuery(this).find("ul").stop().animate({marginTop:"0px"},300,'swing');},function(){jQuery(this).find("ul").stop().animate({marginTop:"-180px"},300,'swing');setTimeout(function(){jQuery(this).find("div").css("display","none");},300);});jQuery(".homeNav").hover(function(){jQuery("ul.subLevel").css("display","none");jQuery(".outsideNavMain a,.insideNav a,.contactNav a").addClass("active");jQuery("ul.homeLevel .insideNav,ul.homeLevel .outsideNav,ul.homeLevel .contactNav").css("display","inline");jQuery(".homeLevel .insideNav").stop().animate({width:"219px"},300,'swing');jQuery(".homeLevel .outsideNavMain").stop().animate({width:"570px"},300,'swing');jQuery(this).find(".home").addClass("active");},function(){jQuery(".homeLevel .insideNav").stop().animate({width:"125px"},300,'swing');jQuery(".homeLevel .outsideNavMain").stop().animate({width:"140px"},300,'swing');jQuery(".outsideNavMain a,.insideNav a,.contactNav a").removeClass("active");if(jQuery("#home").hasClass("homeSec")){jQuery(this).find(".home").addClass("active");}
else{jQuery(this).find(".home").removeClass("active");}
setTimeout(function(){jQuery("ul.subLevel").css("display","block");jQuery("ul.homeLevel .insideNav,ul.homeLevel .outsideNav,ul.homeLevel .contactNav").css("display","none");},100);});}});function menuHighlight(){if(jQuery("#culture,#awards,#team,#careers,#values,#csr").hasClass("insidePm")){jQuery("ul.homeLevel .insideNav,ul.homeLevel .outsideNav,ul.homeLevel .contactNav").css("display","none");jQuery(".subLevel .insideNav").fadeIn(0);jQuery(".subLevel .outsideNav").fadeOut(0);jQuery(".subLevel .contactNav").fadeOut(0);jQuery(".subLevel .curMenuIn").fadeIn(0);jQuery(".subLevel .curMenuIn").removeClass("outsideActive");jQuery(".subLevel .curMenuIn").addClass("insideActive");jQuery(".subLevel .curMenuIn").css("text-indent","0px");jQuery(".navSec ul > li a").removeClass("active");}
}
// custom js
 
// home silder
$(document).ready(function(){
	$('.homecarousel').lightCarousel({
		pagination:true
	});
	

	 $('html, body').animate({
       			 scrollTop: $('.container').offset().top
   			 }, 1);
			 
});
$(document).ready(function(){
	
	//Check to see if the window is top if not then display button
	$(window).scroll(function(){
		if ($(this).scrollTop() > 50) {
			$('.scrollToTop').fadeIn();
			$('nav').css('min-height','50px');
			$('.navbar-brand>img, a.navbar-brand').css({'margin-top':'0','width' : '50px' ,'height' :' 50px'});
			$('ul.nav.navbar-nav').css('margin-top','0px');
			$('.navbar-default .navbar-toggle').css('margin-top','35px');
		} else {
			$('.scrollToTop').fadeOut();
			$('nav').css('min-height','150px');
		$('.navbar-brand>img').css({'margin-top' : '38px', 'width' : '81px' ,'height' : '87px'});
		$('ul.nav.navbar-nav').css('margin-top','44px');
		$('.navbar-default .navbar-toggle').css('margin-top','85px');
		}
	});
	//Click event to scroll to top
	$('.scrollToTop').click(function(){
		$('html, body').animate({scrollTop : 0},800);
		return false;
	});
});

// rotate connect form
$(document).ready(function(){

	$('.image_bg').hover(function(){
		$('.connect_form_sec').slideDown('slow').animate({ opacity: 1}, {queue:false,duration:'fast'});
	});
	$('.connect_form_sec').mouseleave(function(){
	$(this).slideUp('slow').animate({ opacity: 0}, {queue:true,duration:'true'});
	});
});

//services page
$(document).ready(function(){
	
	$('p.our_serv_menu').each(function(){
		$(this).click(function(){
			$(this).find('.serv_rt_content').show();
		//$('.serv_rt_content').show();
	});
	})
	$('ul.tabs-left li').each(function(){
		$(this).click(function(){
			$(this).sibilings('.tab-pane').alert(1);
			
		});
	});
	


});

