
<!DOCTYPE html>
<html lang="en">
 
<head>
	<meta charset="utf-8">
	<title>Godigitell | Careers</title>
	<meta name="viewport" content="initial-scale=1, width=device-width, maximum-scale=1, minimum-scale=1, user-scalable=no">
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link href="css/onepage-scroll.css" rel="stylesheet" type="text/css">
	<link href="css/styles.css" rel="stylesheet" type="text/css">
	
</head>
<body>
<div class="loading"><p>Loading...</p></div>
<!----- Header Start--->   
<header>
<nav class="navbar navbar-default services_nav_deafult navbar-fixed-top services_header">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
	  <a class="navbar-brand" href="index.html"><img class="small_logo_services" src="images/godigitell_small.png" alt="Godigitell_Logo"></a>
    </div>
    <div id="navbar" class="collapse navbar-collapse navbar-right">
      <ul class="nav navbar-nav services_nav">
        </li>
        <li><a class="about_us active" href="about_us.php"><i class="fa fa-info-circle menu_fontawe"></i>About Us</a></li>
        <li><a class="services" href="services.php"><i class="fa fa-cogs menu_fontawe"></i>Services</a></li>
        <li><a class="careers" href="careers.php"><i class="fa fa-briefcase menu_fontawe work_fontawe"></i>Work With Us</a></li>
       <li><a class="testimonials" href="testimonials.php"><i class="fa fa-file-text menu_fontawe_tetsti"></i>Testimonials</a></li>
		 <li><a class="contact_us" href="contactus.php"><i class="fa fa-location-arrow menu_fontawe_cont"></i>Contact Us</a></li>
      </ul>
    </div>
    <!--/.nav-collapse -->
  </div>
 </nav> 

</header>
<!----- HEADER END--->   
	<!-- Main section start ---> 
    <div class="wrapper">
	  <div class="main">
			<!-- section one ---> 
			<section class="careers_sec">
				<div class="container">
					  <div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 careers_inner clearfix">
								<h1>Careers</h1>
								<p><strong>GODIGITELL</strong> is a design and user–focused digital agency. We specialise in solving problems to produce intelligent designs, deliver engaging experiences and build meaningful connections. We work with great clients all over the world to create thoughtful and purposeful products.</p>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 careers_inner_opening clearfix">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 careers_inner_left animated animation-visible animation-visible fadeInLeftNow nocsstransition">
									<figure><img src="images/career.png" alt=""></figure>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 careers_inner_right animated animation-visible animation-visible fadeInRightNow nocsstransition"">
									<div class="panel-group" id="accordion">
										<div class="panel panel-default">
											<div class="panel-heading">
													<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#panel1">
													<h4 class="text-left panel-title accordian_heading">Creative UI Designer</h4></a>
											</div>
											<div id="panel1" class="panel-collapse collapse in">
												<div class="text-left panel-body">
													<h5>Requirements</h5>
													<p>3 to 5 years experience in interactive media design.</p>
													<p>Strong creative sales writing, RFP development, and branding background.</p>
													<p>Strong presentation skills and ability to articulate message clearly.</p>
													<p>Demonstrated ability to work in teams as well as individually.</p>
													<p>Adapt to varying work loads and task requirements under tight deadlines.</p>
													<p>Personable and able to interact well with co-workers, customers, and vendors.</p>
													<p>Agency experience desired.</p>
													<p>Write, edit, format, and review proposals under aggressive deadlines.</p>
													<p class="text-center"><a href="javascript:void(0);"><input type="button" class="applynow" value="Apply Now"></a></p>
												</div>
											</div>
										</div>
										<div class="panel panel-default">
											<div class="panel-heading">
												<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#panel2"><h4 class="text-left panel-title accordian_heading">Graphics Designer</h4></a>
												

											</div>
											<div id="panel2" class="panel-collapse collapse">
												<div class="text-left panel-body">
													<h5>Requirements</h5>
													<p>3 to 5 years experience in interactive media design.</p>
													<p>Strong creative sales writing, RFP development, and branding background.</p>
													<p>Strong presentation skills and ability to articulate message clearly.</p>
													<p>Demonstrated ability to work in teams as well as individually.</p>
													<p>Adapt to varying work loads and task requirements under tight deadlines.</p>
													<p>Personable and able to interact well with co-workers, customers, and vendors</p>
													<p>Agency experience desired</p>
													<p>Write, edit, format, and review proposals under aggressive deadlines</p>
													<p class="text-center"><a href="javascript:void(0);"><input type="button" class="applynow" value="Apply Now"></a></p>
												</div>
											</div>
										</div>
										<div class="panel panel-default">
											<div class="panel-heading">
												<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#panel3"><h4 class="text-left panel-title accordian_heading">HTML Developer</h4></a>
												
											</div>
											<div id="panel3" class="panel-collapse collapse">
												<div class="text-left panel-body">
													<h5>Requirements</h5>
													<p>3 to 5 years experience in interactive media design.</p>
													<p>Strong creative sales writing, RFP development, and branding background.</p>
													<p>Strong presentation skills and ability to articulate message clearly.</p>
													<p>Demonstrated ability to work in teams as well as individually.</p>
													<p>Adapt to varying work loads and task requirements under tight deadlines.</p>
													<p>Personable and able to interact well with co-workers, customers, and vendors</p>
													<p>Agency experience desired</p>
													<p>Write, edit, format, and review proposals under aggressive deadlines</p>
													<p class="text-center"><a href="javascript:void(0);"><input type="button" class="applynow" value="Apply Now"></a></p>		
												</div>
											</div>
										</div>
									</div>
								</div>
					  </div>
				</div> 
			</section>
			
		</div>
	</div>
<!-- Main section end --->
<!-- footer section start -->	

<footer id="footersection">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-xs-12 col-sm-12 col-xs-12 clearfix footer_inner_sec">
						<div class="text-left col-lg-2 col-xs-2 col-sm-2 col-xs-2 footer_inner_cont">	
							<ul class="company_ul">
								<h4>Company</h4>
								<li><a href="javascript:void(0);">Services</a></li>
								<li><a href="javascript:void(0);">Portfolio</a></li>
								<li><a href="javascript:void(0);">Clients</a></li>
								<li><a href="javascript:void(0);">Methodologies</a></li>
								<li><a href="javascript:void(0);">Careers</a></li>
								<li><a href="javascript:void(0);">About Us</a></li>
								<li><a href="javascript:void(0);">Contact Us</a></li>
							</ul>
						</div>
						<div class="text-left col-lg-2 col-xs-2 col-sm-2 col-xs-2 footer_inner_cont">
							<ul class="work_ul">
								<h4>Work</h4>
								<li><a href="javascript:void(0);">Web Design & Development</a></li>
								<li><a href="javascript:void(0);">eCommerce</a></li>
								<li><a href="javascript:void(0);">Marketing Communication</a></li>
								<li><a href="javascript:void(0);">Custom App Development</a></li>
								<li><a href="javascript:void(0);">Products</a></li>
								
							</ul>
						</div>
						<div class="text-left col-lg-5 col-xs-5 col-sm-5 col-xs-5 footer_inner_cont">
							<ul class="services_ul">
								<h4>Services</h4>
								<li class="liLft"><a href="javascript:void(0);">Corporate Sites</a></li>
								<li class="liLft"><a href="javascript:void(0);">Micro Sites</a></li>
								<li class="liLft"><a href="javascript:void(0);">PSD to HTML 5</a></li>
								<li class="liLft"><a href="javascript:void(0);">PSD to Responsive</a></li>
								<li class="liLft"><a href="javascript:void(0);">Wordpress Sites</a></li>
								<li class="liLft"><a href="javascript:void(0);">OpenCart Sites</a></li>
								<li class="liRgt"><a href="javascript:void(0);">Search Engine Optimization</a></li>
								<li class="liRgt"><a href="javascript:void(0);">Search Engine Marketing</a></li>
								<li class="liRgt"><a href="javascript:void(0);">Social Media Marketing</a></li>
								<li class="liRgt"><a href="javascript:void(0);">Mobile Marketing</a></li>
								<li class="liRgt"><a href="javascript:void(0);">Content Writing</a></li>
								<li class="liRgt"><a href="javascript:void(0);">Enterprise Portal</a></li>
								<li class="liRgt"><a href="javascript:void(0);">Business Intelligence Portal</a></li>
							</ul>
							
						</div>
						<div class="text-left col-lg-3 col-xs-3 col-sm-3 col-xs-3 footer_inner_cont">
							<h4 class="keepwithus">Keep With GoDigitell</h4>
							<form class="keepwithus_form">
								<input type="text" class="textfield" id="emailid" value="email address"><i class="rgtarw fa fa-arrow-right"></i>
							</form>
							<ul class="social_icons">
								<li><a href=""><i class="fa fa-facebook"></i></a></li>
								<li><a href=""><i class="fa fa-twitter"></i></a></li>
								<li><a href=""><i class="fa fa-pinterest-p"></i></a></li>
								<li><a href=""><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
				</div>
			</div>
		</div>	
</footer> 
<!-- footer section end -->			
 <a href="javascript:;" class="scrollToTop"><i class="fa fa-angle-up"></i></a>
<!-- Js Files -->
	<script src="js/plugins.js"></script>
	<script src="js/gridlayout.js"></script> 
	<script src="js/modernizr.custom.js"></script> 
	<!--<script type="text/javascript" src="js/jquery.onepage-scroll.js"></script>-->
	<script type="text/javascript" src="js/scripts.js"></script>

</body>
</html>
