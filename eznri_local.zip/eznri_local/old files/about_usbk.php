<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <title>EZNRI | About Us </title>
    <!-- CSS Files -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link href="css/style.css" rel="stylesheet">
		<link type="text/css" href="css/animation.css" rel="stylesheet">
  </head>

  <body><div class="loading"><p>Loading...</p></div>
 
<header>  
  <div id="header_top">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 htop clearfix">
				<div class="htop_left txtLft">
					<ul class="contacts">
						<li><p><span><img src="images/time.png" alt=""></span>Mon-Fri</p></li>
						<li><p><span><img src="images/phone.png" alt=""></span><a href="tel:9500068580">9500068580/20</a></p></li>
						<li><p><span><img src="images/mail.png" alt=""></span><a href="mailto:Contact@eznri.com">contact@eznri.com</a></p></li>
					</ul>
				</div>
				<div class="htop_right txtRgt">
					<ul class="social_icons">
						<li><i class="fa fa-facebook"></i></li>
						<li><i class="fa fa-twitter"></i></li>
						<li><i class="fa fa-google-plus"></i></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
  </div>
<nav class="navbar navbar-default navbar-fixed-top clearfix" role="navigation">
 <!-- Header Top -->
	
  <div class="container clearfix">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-main"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand txtLft" href="index.html"><img src="images/eznri_logo.png" alt=""></a> </div>
    <div class="collapse navbar-collapse" id="navbar-collapse-main">
      <ul class="nav navbar-nav txtRgt">
      <li><a class="about_us active" href="about_us.php"><i class="fa fa-info-circle menu_fontawe"></i>About Us</a></li>
        <li><a class="services" href="services.php"><i class="fa fa-cogs menu_fontawe"></i>Services</a></li>
        <li><a class="careers" href="careers.php"><i class="fa fa-briefcase menu_fontawe work_fontawe"></i>Work With Us</a></li>
       <li><a class="testimonials" href="testimonials.php"><i class="fa fa-file-text menu_fontawe_tetsti"></i>Testimonials</a></li>
		 <li><a class="contact_us" href="contactus.php"><i class="fa fa-location-arrow menu_fontawe_cont"></i>Contact Us</a></li>
      </ul>
    </div>
  </div>
</nav>
<!-- Navbar End --->
</header>
 <!-- Main Section Start -->
 <div class="wrapper">
	<!-- About Us Page-->
			<section class="banner">
				<div class="container-fluid services_banner animated animation-visible fadeInDownNow nocsstransition">
					<figure><img src="images/abouts_banner.jpg" alt=""></figure>
				</div>
			</section>
			<section  class="pad-sec" id="about_us_page">
				<div class="container">
					<div class="row clearfix">
						<h1 class="home_page_heading text-left animated animation-visible fadeInLeftNow nocsstransition">About Us</h1>
						<h3 class="work_heading animated animation-visible fadeInLeftNow nocsstransition">It works as simple as this with us</h3>
					<div class="row animated animation-visible fadeInRightNow nocsstransition">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix">
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 steps_col text-center">
								<div class="work_steps">
									<figure><img src="images/step_one.png" alt=""><figcaption>Step 1</figcaption></figure>
									<p>Let us know your requirement by submitting the online form.</p>
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 steps_col text-center">
								<div class="work_steps">
									<figure><img src="images/step_two.png" alt=""><figcaption>Step 2</figcaption></figure>
									<p>Our executive shall be in touch with you as early as possible.</p>
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 steps_col text-center">
								<div class="work_steps">
									<figure><img src="images/step_three.png" alt=""><figcaption>Step 3</figcaption></figure>
									<p>We shall send you a link with time required along with the applicable charges.</p>
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 steps_col text-center">
								<div class="work_steps">
									<figure><img src="images/step_four.png" alt=""><figcaption>Step 4</figcaption></figure>
									<p>Upon receiving the payment, the work shall be completed on the said time.</p>
								</div>
							</div>
						</div>
					</div>
						
					</div>
				</div>	
			</section>
		<!-- About Us end-->
	<!-- NRI Services Banner start--->
		<section id="home_page_banner" class="pad-sec">
			<div id="home_banner">
				<div class=" home_banner_sec">
					<div class="container">
						<div class="row clearfix">
							<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
								<div class="col-lg-8 col-md-8 col-xs-8 col-sm-8 home_banner_left">
									<h2 class="feelfree_heading">Get in touch with the perfect experts without any hindrances!</h2>	
									<!--<p class="bestnri">We give the best NRI services</p>-->
								</div>
								<div class="col-lg-4 col-md-4 col-xs-4 col-sm-4 call_now txtRgt">
									<a class="callnow txtRgt" href="javascript:void(0);"> Call us now</a>
								</div>
							</div>
						</div>
					</div>		
				</div>	
			</div>
		</section>
		<!-- NRI Services Banner end--->
			<section id="work_sec" class="pad_sec">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 abt_cont">
								<p class="home_page_para text-left animated animation-visible fadeInRightNow nocsstransition">There had been many servicing agencies in house who process travel needs, property management services or shipping services. But, serving a client offshore and ensuring that there is seamless communication on both the ends is a service that we would want to focus on. Our dedicated team of client servicing and the technology built behind in getting the communication rightly done, ensures that we provide the best in class services to our NRI clients.</p>
						</div>
					</div>
					<div class="row clearfix">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix company_details">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 company_logo animated animation-visible fadeInLeftNow nocsstransition">
								<figure><img src="images/company.jpg" alt=""></figure>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 abt_company">
								<div class="abt_company_details">
									<h3 class="abtus_heading animated animation-visible fadeInDownNow nocsstransition">our company</h3>
									<p class="abtus_cont animated animation-visible fadeInUpNow nocsstransition">Placed in Chennai, we have started with a team of a handful of client servicing professionals with a wide database of experts(from drivers to doctors, from tailors to travel partners) in the various domains who could get any kind of job done to our clients. </p>	
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!-- Work  end-->
 </div> <!-- Main Section End -->
 <!-- Footer Start -->
 <footer id="footer_menu">
	<div class="footer_section">
		<div class="container">
			<div class="row clearfix">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix padzero">
							<div class="ftr_content">
								<h2>Contact Details</h2>
								<div class="ftr_contact">
									<ul class="ul_left">
										<li class="clearfix"><span class="fa_map"><i class="fa fa-map-marker"></i></span><span class="con_address">33/18, 1st Floor, Anna Main Road, MGR Nagar, Chennai – 78</span></li>
										<li class="clearfix"><span class="fa_map"><i class="fa fa-phone"></i></span><a href="tel:9500068580" class="con phone">9500068580/20</a></li>
										<li class="clearfix"><span class="fa_map"><i class="fa fa-envelope-o"></i></span><a href="mailto:Contact@eznri.com" class="con mail" >contact@eznri.com</a></li>
									</ul>
									<ul class="usefullinks">
										<h2>Useful Links</h2>
										<li><a href="about_us.html">About Us</a></li>
										<li><a href="services.html">Services</a></li>
										<li><a href="careers.html">Work With Us</a></li>
										<li><a href="testimonials.html">Testimonials</a></li>
										<li><a href="contactus.html">Contact Us</a></li>
									</ul>
									<ul class="socials text-center">
										<h2>Follow Us</h2>
										<li><a href="https://www.facebook.com/eznri/?fref=ts" target="_blank"><i class="fa fa-facebook"></i></a></li>
										<li><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
										<li><a href="javascript:void(0);"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
					
					
				</div>
			</div>
			<div class="copyrights">
				
				<hr>
				<p class="text-center">Copyright &copy; 2016, All Right Reserved, <span class="godigitell"><a href="http://godigitell.com/" target="_blank">Godigitell.com</a></span></p>
			</div>
		</div>	
	</div>
 </footer> <!-- Footer End -->
<a href="#" class="scrollToTop"><i class="fa fa-angle-up"></i></a>
 <!-- Rotate Form -->
 <div class="txtRgt">
	<div class="rotate_connecting">
		<div class="rotate_image">
			<p class="image_bg"><img id="image_rot" src="images/Connect_34.png" alt=""></p>
			<div class="connect_form_sec">
					<form method="get" class="connect_form">
						<p><input type="text" placeholder="Name" class="inputfield"></p>
						<p><input type="text" placeholder="Number" class="inputfield"></p>
						<p><input type="email" placeholder="Email ID" class="inputfield"></p>
						<p><input type="text" placeholder="Country" class="inputfield"></p>
						<p><input type="text" placeholder="Message" class="inputfield"></p>
						<p><input type="submit" placeholder="Send" class="inputfield submitbtn"></p>
					</form>
			</div>
		</div>
	</div>
 </div>
 <!-- JS Files -->
	<script src="js/plugins.js"></script>
	<script src="js/gridlayout.js"></script> 
	<script src="js/jquery.light-carousel.js"></script> 
	<script src="js/modernizr.custom.js"></script> 
	<script src="js/jQueryRotateCompressed.js"></script>
	<script src="js/custom.js" ></script> 


  </body>
</html>
