<?php

$con = mysqli_connect("jazparty.db.11765384.hostedresource.com","jazparty","Godrive@321","jazparty");
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$name = $_REQUEST['regname'];
$email = $_REQUEST['regemail'];
$contact_no = $_REQUEST['regno'];
$address = $_REQUEST['regaddr'];
$message = $_REQUEST['regcomm'];
$course = $_REQUEST['course'];
$admin_email = "ansar@godrive.co.in";

$sql_query = "INSERT INTO `jazparty`.`member` (`member_name`, `email`, `mobile`, `address`, `course`, `message`) VALUES ('$name', '$email', '$contact_no', '$address', '$course', '$message')";

mysqli_query($con, $sql_query);


//User Email

$to = $email;
$subject = "[MozhiFoundation] Thanks for your interest";
$txt = "Hi $name, Thanks for your interest, we will keep in touch with you shortly \r\n

Regards
MozhiFoundation Admin";
$headers = "From: info@mozhifoundation.com" . "\r\n" .
"CC: ansar@godrive.co.in";

mail($to,$subject,$txt,$headers);

//User Email Ends


// Admin Mail Starts

//admin mail
$subject1 = "User  Registeration Details:";
$from_name1 = "GoDigitell";
$from_email1 = "info@mozhifoundation.com";


$txt1 = "An user  Register the below information.<br> \r\n\n";
$txt1 .= "Name &thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;: ".$name." <br>\r\n";
$txt1 .= "Email &thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;: ".$email." <br>\r\n";
$txt1 .= "Contact &thinsp;&thinsp;&thinsp;: ".$contact_no ." <br>\r\n";
$txt1 .= "Address &thinsp;&thinsp;: &#09;".$address." <br>\r\n";
$txt1 .= "Course &thinsp;&thinsp;&thinsp; : &#09;".$course ." <br>";
$txt1 .= "Comment: &#09;".$message ." <br>";

$headers1 = "From: ".$from_name1."<".$from_email1. ">\r\n" ;
$headers1 .= "MIME-Version: 1.0\r\n"; 
$headers1 .= "Content-Type: text/html; charset=ISO-8859-1\r\n"; 
$headers1 .= "X-Priority: 1\r\n";



mail($admin_email,$subject1,$txt1,$headers1);



//Admin Mail Ends



header("location:thanku.html");



?>