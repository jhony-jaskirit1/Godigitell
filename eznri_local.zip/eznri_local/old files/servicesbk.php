
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <title>EZNRI | Services</title>
   <!-- CSS Files -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link href="css/style.css" rel="stylesheet">
		<link type="text/css" href="css/animation.css" rel="stylesheet">
		<style>
		.tabcontent .tab_pane_inner_cont{
			margin-top:60px;
		}
		.tabcontent .personal_tab{
			margin-top:0;
		}
		</style>
  </head>
<body><div class="loading"><p>Loading...</p></div>
<header> 
  <div id="header_top">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 htop clearfix">
				<div class="htop_left txtLft">
					<ul class="contacts">
						<li><p><span><img src="images/time.png" alt=""></span>Mon-Sat</p></li>
						<li><p><span><img src="images/phone.png" alt=""></span><a href="tel:9500068580">9500068580/20</a></p></li>
						<li><p><span><img src="images/mail.png" alt=""></span><a href="mailto:Contact@eznri.com">contact@eznri.com</a></p></li>
					</ul>
				</div>
				<div class="htop_right txtRgt">
					<ul class="social_icons">
						<li><i class="fa fa-facebook"></i></li>
						<li><i class="fa fa-twitter"></i></li>
						<li><i class="fa fa-google-plus"></i></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
  </div> 
<nav class="navbar navbar-default navbar-fixed-top clearfix" role="navigation">
 <!-- Header Top -->
	
  <div class="container clearfix">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-main"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand txtLft" href="index.html"><img src="images/eznri_logo.png" alt=""></a> </div>
    <div class="collapse navbar-collapse" id="navbar-collapse-main">
      <ul class="nav navbar-nav txtRgt">
        <li><a class="about_us active" href="about_us.php"><i class="fa fa-info-circle menu_fontawe"></i>About Us</a></li>
        <li><a class="services" href="services.php"><i class="fa fa-cogs menu_fontawe"></i>Services</a></li>
        <li><a class="careers" href="careers.php"><i class="fa fa-briefcase menu_fontawe work_fontawe"></i>Work With Us</a></li>
       <li><a class="testimonials" href="testimonials.php"><i class="fa fa-file-text menu_fontawe_tetsti"></i>Testimonials</a></li>
		 <li><a class="contact_us" href="contactus.php"><i class="fa fa-location-arrow menu_fontawe_cont"></i>Contact Us</a></li>
      </ul>
    </div>
  </div>
</nav>
<!-- Navbar End --->
</header>
 <!-- Main Section Start -->
 <div class="wrapper">
	<!-- Services Page-->
			<section class="banner">
				<div class="container-fluid services_banner animated animation-visible fadeInDownNow nocsstransition">
					<figure><img src="images/services_banner.jpg" alt=""></figure>
				</div>
			</section>
			<section class="pad_sec" id="services_page">
				<div class="container">
					<div class="row clearfix">
							<h1 class="home_page_heading text-left animated animation-visible fadeInLeftNow nocsstransition">Services</h1>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 services_cont">
								<p class="home_page_para text-left animated animation-visible fadeInRightNow nocsstransition">‘Feel at Home’ has been our motto statement to the Indian families abroad. We facilitate all that we could do to you here to ensure that you would never miss your home country at any instances. Other than your feeling of sitting at your hometown with your kith and kin based here, we could replace all that we could with the best efforts and best in class services. We extend our services based on your need be it your personalized requirement, travel based services, property based necessity or a shopping requirement.</p>
							</div>
					</div>
					<div class="row clearfix">
						
						<div id="tabs">
							<ul class="tabs">
								<h2 class="services_heading">What we do</h2>
								<li data-tabs="tab1"><a href="#personal_services">Personal Services</a></li>
								<li data-tabs="tab2"><a href="#property_services">Property Services</a></li>
								<li data-tabs="tab3"><a href="#tourist_services">Tourist Services</a></li>
								<li data-tabs="tab4"><a href="#shoppings_services">Shopping Services</a></li>
							</ul>
						
							<div id="personal_services" class="tabcontent">
									<div class="tab_pane_inner_cont personal_tab">
										<div class="services_inner_cont">
											<h3>Personalized Services</h3>
											<ul class="work_ul">
												<li class="clearfix">
													<span class="services_image"><img src="images/personal/pass.png" alt=""></span>
													<div class="services_li ser_page_li">	<h4>Arranging Visa For Family</h4>
														<p class="services_para">Arranging a visa for your family put up in India is time consuming and tedious too. We help your kith and kins by guiding them through the visa documentation and process, committed to provide an effective and efficient visa information on application for personal, business and tourist purposes.</p></div>
												</li>
												<li class="clearfix">
													<span class="services_image"><img src="images/personal/paying_bills_1.png" alt=""></span>
														<div class="services_li ser_page_li"><h4>Paying bills / taxes</h4>
														<p class="services_para">Paying bills/taxes being a resident of India itself is boring and time consuming. Staying away from the country makes it even more complex. Stop worrying! We would take the responsible in paying your bills and taxes on time and shall also send you periodic reminders on the same.</p></div>
												</li>
												<li class="clearfix">
													<span class="services_image"><img src="images/personal/tailoring_3.png" alt=""></span>
														<div class="services_li ser_page_li"><h4>Tailoring Assistance</h4>
														<p class="services_para">There is always a craze and passion for Indian clothing. Be it the Banarasi silk or the Jaipuri cotton. EZNRI provides you a solution for this. We give you shopping as well as tailoring assistance. We get your clothing ready and would also ship them to you if required.</p></div>
												</li>
												<li class="clearfix">
													<span class="services_image"><img src="images/personal/indian-job.png" alt=""></span>
														<div class="services_li ser_page_li"><h4>Indian Job Recruitment Services</h4>
														<p class="services_para">Finding a job in India from abroad is not easy. We can help you search for jobs in India. We would identify your needs, match you to appropriate vacancies and support you with your search for the right career opportunity.</p></div>
												</li>
												<li class="clearfix">
													<span class="services_image"><img src="images/personal/party.png" alt=""></span>
														<div class="services_li ser_page_li"><h4>Event Organizing/Management</h4>
														<p class="services_para">Your events planned to be executed in India may demand your time too much in prior to plan and meet people who would have to support you right from the caterers to a professional photographer. Forget the pain and just be here on the day of the event and we do the stressful part on your behalf.</p></div>
												</li>
												<li class="clearfix">
														<span class="services_image"><img src="images/personal/connecting_people.png" alt=""></span>
														<div class="services_li ser_page_li"><h4>Connecting to the required professional</h4>
														<p class="services_para">You may have to consult a skin specialist or you may require to talk to a lawyer for an opinion. Whoever the professional be, we help you connect with the right people to get all your clarifications and queries sorted.</p></div>
												</li>
												<li class="clearfix">
													<span class="services_image"><img src="images/personal/arranging_needs.png" alt=""></span>
														<div class="services_li ser_page_li"><h4>Arranging needs for elderly parents</h4>
														<p class="services_para">Though staying abroad increases the family status, there is always a feel of missing the elderly parents out here. Just give us a buzz to help your parents with what they need right away.</p></div>
												</li>
												<li class="clearfix">
													<span class="services_image"><img src="images/personal/selling_old_furn.png" alt=""></span>
														<div class="services_li ser_page_li"><h4>Selling out old furniture / items</h4>
														<p class="services_para">You would have had a chance to leave abroad in just a couple of days and there would not be sufficient time in disposing unwanted furniture’s/items. We help you in selling all your old good and transferring the money to you</p></div>
												</li>
											</ul>
										</div>
									</div>
							</div>
							<div id="property_services" class="tabcontent">
								<div class="tab_pane_inner_cont">
										<div class="services_inner_cont">
											<h3>Property Services</h3>
											<ul class="work_ul">
												<li class="clearfix">
													<span class="services_image"><img src="images/property_servivces/buy_sales.png" alt=""></span>
														<div class="services_li ser_page_li"><h4>Buy | Sell</h4>
														<p class="services_para">Buying/Selling Property is always a nightmare, especially when you stay away from the country. Right from the genuine builders/buyers to the proper legal stamp partners, we need to be double sure that whatever being done is under proper supervision.</p></div>
												</li>
												<li class="clearfix">
													<span class="services_image"><img src="images/property_servivces/renr.png" alt=""></span>
														<div class="services_li ser_page_li"><h4>Lease | Rent</h4>
														<p class="services_para">EZNRI is your specialized guide to leasing or renting properties in India. We guide and help you throughout the process right from identifying the tenant, to validating their credentials to closing the agreement formalities. We also ensure that the tenant is using the property in right means.</p></div>
												</li>
												<li class="clearfix">
													<span class="services_image"><img src="images/property_servivces/bank.png" alt=""></span>
														<div class="services_li ser_page_li"><h4>Loan Processing Assistance</h4>
														<p class="services_para">We help you get connected with the banking professionals to get your loan processing done for new property, pre-approved loans, second hand properties or loan against property. We also get all the paper work done on your behalf and keep you updated on the status time to time.</p></div>
												</li>
												<li class="clearfix">
													<span class="services_image"><img src="images/property_servivces/cleaning.png" alt=""></span>
														<div class="services_li ser_page_li"><h4>Cleaning or Regular Maintenance</h4>
														<p class="services_para">We help in periodic cleaning of your closed house to ensure them away from dirt and germs. We are offering solutions on your daily activities like flat maintenance, commercial complex maintenance, plumbing, electrical, mason works, cracked building, water leakage, kitchen alteration, painting and all kinds of home care support.</p></div>
												</li>
												<li class="clearfix">
													<span class="services_image"><img src="images/property_servivces/renovation.png" alt=""></span>
														<div class="services_li ser_page_li"><h4>Renovation</h4>
														<p class="services_para">We would help you in demolishing and reconstruction, modular kitchens and any other major construction and interior decoration changes. We would update you with the latest pictures of the completed property for your complete satisfaction.</p></div>
												</li>
												<li class="clearfix">
													<span class="services_image"><img src="images/property_servivces/interior.png" alt=""></span>
														<div class="services_li ser_page_li"><h4>Interior Designing</h4>
														<p class="services_para">Discover stylish interior design ideas for your home in India, with the latest interior inspiration and décor pictures and tips for every room, right from House to Garden. </p></div>
												</li>
												
											</ul>
										</div>
								</div>
							</div>
							<div id="tourist_services" class="tabcontent">
								<div class="tab_pane_inner_cont">
									<div class="services_inner_cont">
										<h3>Tourist Services</h3>
										<ul class="work_ul">
											<li class="clearfix">
												<span class="services_image"><img src="images/tourist services/serviced-Appartment.png" alt=""></span>
													<div class="services_li ser_page_li"><h4>Serviced Apartments during stay</h4>
													<p class="services_para">Stay at the luxurious, comfortable and stylishly designed serviced apartments on your trip to India. We help you on your trip to your home country. We arrange for your visits and stays for the tourist spot you wish to visit. We also help you find economic class serviced apartments.</p></div>
											</li>
											<li class="clearfix">
												<span class="services_image"><img src="images/tourist services/rental_cars.png" alt=""></span>
													<div class="services_li ser_page_li"><h4>Rental car services</h4>
													<p class="services_para">Make your car reservation when you plan for a trip to India, through our tourist services from EZNRI. We offer you the best car rental prices on luxury, economic, and family rental cars.</p></div>
											</li>
											<li class="clearfix">
												<span class="services_image"><img src="images/tourist services/drivers.png" alt=""></span>
													<div class="services_li ser_page_li"><h4>Drivers on call</h4>
													<p class="services_para">Traveling in your own car comforts you, but traveling with unknown drivers can make you feel uncomfortable. We help you find trusted experienced driver services for you to make your travel to a satisfying journey.</p></div>
											</li>
											<li class="clearfix">
												<span class="services_image"><img src="images/tourist services/tourist_booking.png" alt=""></span>
													<div class="services_li ser_page_li"><h4>Hotel / Tourist booking</h4>
													<p class="services_para">Set against a beautiful ambience when you reach India. Get great deals on booking hotels anywhere in India through EZNRI.</p></div>
											</li>
																							
										</ul>
									</div>
								</div>
							</div>
							<div id="shoppings_services" class="tabcontent">
								<div class="tab_pane_inner_cont">
									<div class="services_inner_cont">
										<h3>Shopping Services</h3>
										<ul class="work_ul">
											<li class="clearfix">
												<span class="services_image"><img src="images/shopping/shipping.png" alt=""></span>
													<div class="services_li ser_page_li"><h4>Shipping Services</h4>
													<p class="services_para">We have a tie-ups with world leading shipping services company to fulfil your shipping requirements, even during times when you miss your mother’s recipe.</p></div>
											</li>
											<li class="clearfix">
												<span class="services_image"><img src="images/shopping/shopping.png" alt=""></span>
													<div class="services_li ser_page_li"><h4>Personalized shopping requirement</h4>
													<p class="services_para">We help you find your niche shopping requirements through EZNRI. Tell us your need once, and get your products frequently with more offered prices and additional freebies</p></div>
											</li>
											<li class="clearfix">
												<span class="services_image"><img src="images/shopping/medicine.png" alt=""></span>
													<div class="services_li ser_page_li"><h4>Medicines to be shipped</h4>
													<p class="services_para">Indian People who stay abroad take with them their own set of Indian medicines. EZNRI does it as a special service, where we will ship medicines to your place directly.</p></div>
											</li>
											<li class="clearfix">
												<span class="services_image"><img src="images/shopping/gift.png" alt=""></span>
													<div class="services_li ser_page_li"><h4>Special gifts for Indians</h4>
													<p class="services_para">Your special ones and your loved family members here would be super excited to see your gifts to them from here. We offer you specialized solutions where we get you with whatever you wanted and deliver it to them on time. Be it a birthday cake, a flower bouquet or anything you wish to, do not forget to ping us for getting it done.</p></div>
											</li>
																							
										</ul>
									</div>
								</div>
							</div>
							
						</div>
						
					</div>
				</div>
			</section>
		<!-- Services end-->
 </div> <!-- Main Section End -->
 <!-- Footer Start -->
 <footer id="footer_menu">
	<div class="footer_section">
		<div class="container">
			<div class="row clearfix">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix padzero">
							<div class="ftr_content">
								<h2>Contact Details</h2>
								<div class="ftr_contact">
									<ul class="ul_left">
										<li class="clearfix"><span class="fa_map"><i class="fa fa-map-marker"></i></span><span class="con_address">33/18, 1st Floor, Anna Main Road, MGR Nagar, Chennai – 78</span></li>
										<li class="clearfix"><span class="fa_map"><i class="fa fa-phone"></i></span><a href="tel:9500068580" class="con phone">9500068580/20</a></li>
										<li class="clearfix"><span class="fa_map"><i class="fa fa-envelope-o"></i></span><a href="mailto:Contact@eznri.com" class="con mail" >contact@eznri.com</a></li>
									</ul>
									<ul class="usefullinks">
										<h2>Useful Links</h2>
										<li><a href="about_us.html">About Us</a></li>
										<li><a href="services.html">Services</a></li>
										<li><a href="careers.html">Work With Us</a></li>
										<li><a href="testimonials.html">Testimonials</a></li>
										<li><a href="contactus.html">Contact Us</a></li>
									</ul>
									<ul class="socials text-center">
										<h2>Follow Us</h2>
										<li><a href="https://www.facebook.com/eznri/?fref=ts" target="_blank"><i class="fa fa-facebook"></i></a></li>
										<li><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
										<li><a href="javascript:void(0);"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
					
					
				</div>
			</div>
			<div class="copyrights">
				
				<hr>
				<p class="text-center">Copyright &copy; 2016, All Right Reserved, <span class="godigitell"><a href="http://godigitell.com/" target="_blank">Godigitell.com</a></span></p>
			</div>
		</div>	
	</div>
 </footer> <!-- Footer End -->
 <a href="#" class="scrollToTop"><i class="fa fa-angle-up"></i></a>
 
  <!-- JS Files -->
	<script src="js/plugins.js"></script>
	<script src="js/gridlayout.js"></script> 
	<script src="js/jquery.light-carousel.js"></script> 
	<script src="js/modernizr.custom.js"></script> 
	<script src="js/jQueryRotateCompressed.js"></script>
	<script src="js/custom.js" ></script> 
	<script>
$(function(e) {
		//$('.tabcontent').hide().filter(':first').show();
		$('#tabs li[data-tabs]').on('click', function () {
		$('#tabs li[data-tabs]').removeClass('active');
		//$('.tabcontent').hide();
		var tab = $(this).data('tabs');
		$(this).addClass('active');
		$('#' + tab).fadeIn().show();
		});
		$(".tabs li").click(function(){
			var  cur =$(".tabs li").index(this);
			var elm = $('.tabcontent:eq('+cur+')');
			//elm.addClass("fadeinright");
			setTimeout(function() {
				//elm.removeClass("fadeinright");
			}, 220);
		});
});



	</script>
  </body>
</html>
