<?php
$con = mysqli_connect("jazparty.db.11765384.hostedresource.com","jazparty","Godrive@321","jazparty");
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>