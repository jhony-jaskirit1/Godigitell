
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <title>EZNRI | Contact Us </title>
    <!-- CSS Files -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link href="css/style.css" rel="stylesheet">
		<link href="css/bootstrap-multiselect.css" rel="stylesheet">
		<link type="text/css" href="css/animation.css" rel="stylesheet">
  </head>
 <body><div class="loading"><p>Loading...</p></div>
<header>
<div id="header_top">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 htop clearfix">
				<div class="htop_left txtLft">
					<ul class="contacts">
						<li><p><span><img src="images/time.png" alt=""></span>Mon-Sat</p></li>
						<li><p><span><img src="images/phone.png" alt=""></span><a href="tel:9500068580">9500068580/20</a></p></li>
						<li><p><span><img src="images/mail.png" alt=""></span><a href="mailto:Contact@eznri.com">contact@eznri.com</a></p></li>
					</ul>
				</div>
				<div class="htop_right txtRgt">
					<ul class="social_icons">
						<li><a href="https://www.facebook.com/eznri/?fref=ts" target="_blank"><i class="fa fa-facebook"></i></a></li>
						<li><a href="https://twitter.com/EZ_NRI" target="_blank"><i class="fa fa-twitter"></i></a></li>
						<li><a href="https://plus.google.com/u/0/102742721967205623609" target="_blank"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
  </div>  
<nav class="navbar navbar-default navbar-fixed-top clearfix" role="navigation">
 <!-- Header Top -->
  	
  <div class="container clearfix">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-main"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand txtLft" href="index.php"><img src="images/eznri_logo.png" alt=""></a> </div>
    <div class="collapse navbar-collapse" id="navbar-collapse-main">
    <ul class="nav navbar-nav txtRgt">
        <li><a class="about_us" href="about_us.php"><i class="fa fa-info-circle menu_fontawe"></i>About Us</a></li>
        <li><a class="services" href="services.php"><i class="fa fa-cogs menu_fontawe"></i>Services</a></li>
        <li><a class="careers" href="workwithus.php"><i class="fa fa-briefcase menu_fontawe work_fontawe"></i>Work With Us</a></li>
       <li><a class="testimonials" href="testimonials.php"><i class="fa fa-file-text menu_fontawe_tetsti"></i>Testimonials</a></li>
		 <li><a class="contact_us" href="contactus.php"><i class="fa fa-location-arrow menu_fontawe_cont"></i>Contact Us</a></li>
      </ul>
    </div>
  </div>
</nav>
<!-- Navbar End --->
</header>
 <!-- Main Section Start -->
 <div class="wrapper">
	<section id="contactus_sec" class="contact_page">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix">
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 contactus_frm_left animated animation-visible fadeInDownNow nocsstransition">
						<h1>Keep in touch with us?</h1>
						 
						<form class="contactform" id="contactfrm" method="post" action="contactus2.php">
							<span><input type="text" placeholder="Your Name *" name ="name" id="con_name" class="contact_fields form-control" required></span>
							<span><input type="text" placeholder="Contact Number *" name ="mobile" id="con_no" class="contact_fields form-control" required></span>
							<span><input type="text" placeholder="Email Address *" name ="email" id="con_email" class="contact_fields form-control" required></span>
							<span class="select_box contact_select">
							   <span class="contact_arrow arrow"> <i class="fa fa-angle-down"></i></span>
							   <select class="contact_fields" name ="country" id="menulist">
									<option value="Country you belong to?">Country you belong to?</option>
									<option value="Australia">Australia</option>
									<option value="China">China</option>
									<option value="India">India</option>
									<option value="Japan">Japan</option>
									<option value="Russia">Russia</option>
									<option value="United">United Kingdom</option>
									<option value="USA">United States of America</option>        
							   </select>    
							</span>
							<span class="select_box contact_select">
							   <span class="contact_arrow arrow"> <i class="fa fa-angle-down"></i></span>
							   <select class="contact_fields" name ="service" id="menulist_two">
									<option value="Service Required">Service Required</option>
									<option value="Personal">Personal Services</option>
									<option value="Property">Property Services</option>
									<option value="Tourist">Tourist Services</option>
									<option value="Shopping">Shopping Services</option>
									<option value="Other">Other Services</option>
							   </select>    
							</span>
							<span><textarea type="text"  name ="message" class="contact_fields" placeholder="Please Add Your Comments / Additonal Details"></textarea></span>
							<span><input type="submit" id="submitbtn" class="contact_fields" value="Submit Now" onclick="return contact_form();"></span>
						</form>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 contactus_frm_right animated animation-visible fadeInDownNow nocsstransition">
						<h1>Other Contact Details?</h1>
						<div class="contact_addr">
							<p>Initiative of GoDrive Solutions Pvt. Ltd.</p>
							<ul class="contact_ul">
								<li>33/18, 1st Floor, Anna Main Road</li>
								<li>MGR Nagar, Chennai – 78</li>
								<li>Ph: 00914443586155 / 00919500068520</li>
								<li>Email – preetha@godrive.co.in</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 contactus_map contactform animated animation-visible fadeInUpNow nocsstransition">
					<h1 class="text-center">Find Us On Map</h1>
					<div id="contact_map">
						
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3886.9897680368485!2d80.19828561423317!3d13.036323116983354!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5266d84ec0cd01%3A0x89179d0012beb154!2sEZ+NRI+Services!5e0!3m2!1sen!2sin!4v1454992786134" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
					</div>
				</div>
			</div>
		</div>
	</section>
 </div> <!-- Main Section End -->
 <!-- Footer Start -->
 <footer id="footer_menu">
	<div class="footer_section">
		<div class="container">
			<div class="row clearfix">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix padzero">
							<div class="ftr_content">
								<h2>Contact Details</h2>
								<div class="ftr_contact">
									<ul class="ul_left">
										<li class="clearfix"><span class="fa_map"><i class="fa fa-map-marker"></i></span><span class="con_address">33/18, 1st Floor, Anna Main Road, MGR Nagar, Chennai – 78</span></li>
										<li class="clearfix"><span class="fa_map"><i class="fa fa-phone"></i></span><a href="tel:9500068580" class="con phone">9500068580/20</a></li>
										<li class="clearfix"><span class="fa_map"><i class="fa fa-envelope-o"></i></span><a href="mailto:Contact@eznri.com" class="con mail" >contact@eznri.com</a></li>
									</ul>
									<ul class="usefullinks">
										<h2>Useful Links</h2>
										<li><a href="about_us.php">About Us</a></li>
										<li><a href="services.php">Services</a></li>
										<li><a href="careers.php">Work With Us</a></li>
										<li><a href="testimonials.php">Testimonials</a></li>
										<li><a href="contactus.php">Contact Us</a></li>
									</ul>
									<ul class="socials text-center">
										<h2>Follow Us</h2>
										<li><a href="https://www.facebook.com/eznri/?fref=ts" target="_blank"><i class="fa fa-facebook"></i></a></li>
										<li><a href="https://twitter.com/EZ_NRI" target="_blank"><i class="fa fa-twitter"></i></a></li>
										<li><a href="https://plus.google.com/u/0/102742721967205623609" target="_blank"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
					
					
				</div>
			</div>
			<div class="copyrights">
				
				<hr>
				<p class="text-center">Copyright &copy; 2016, All Right Reserved, <span class="godigitell"><a href="http://godigitell.com/" target="_blank">Godigitell.com</a></span></p>
			</div>
		</div>	
	</div>
 </footer> <!-- Footer End -->
 <a href="#" class="scrollToTop"><i class="fa fa-angle-up"></i></a>
  <!-- Rotate Form -->
 <div class="txtRgt">
	<div class="rotate_connecting">
		<div class="rotate_image">
			<p class="image_bg"><img id="image_rot" src="images/Connect_34.png" alt=""></p>
			<div class="connect_form_sec">
					<form method="get" class="contactus2.php">
						<p><input type="text" name ="name" placeholder="Name" class="inputfield"></p>
						<p><input type="text" name ="number" placeholder="Number" class="inputfield"></p>
						<p><input type="email" name ="email" placeholder="Email ID" class="inputfield"></p>
						<p><input type="text" name ="country" placeholder="Country" class="inputfield"></p>
						<p><input type="text" name ="message" placeholder="Message" class="inputfield"></p>
						<!--<p><input type="submit" placeholder="Send" class="inputfield submitbtn"></p>-->
						<button type="submit" name="btn-signup">Sign Me Up</button>
					</form>
			</div>
		</div>
	</div>
 </div>
 <!-- JS Files -->
	<script src="js/plugins.js"></script>
	<script src="js/gridlayout.js"></script> 
	<script src="js/jquery.light-carousel.js"></script> 
	<script src="js/modernizr.custom.js"></script> 
	<script src="js/jQueryRotateCompressed.js"></script>
	<script src="js/bootstrap-multiselect.js"></script>
	<script src="js/custom.js" ></script> 
	<script>
		$(document).ready(function(){
				$('#submitbtn').click(function(){
			var contactname=$('#con_name').val();
			var contactno=$('#con_no').val();
			var conemailid=$('#con_email').val();
			var selectone=$('#menulist').val();
			var selecttwo=$('#menulist_two').val();
			var emailpattern=/^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
			var phexp=/^\d*[0-9](|.\d*[0-9]|,\d*[0-9])?$/;
			if(contactname == 'Your Name *'){
				$('#con_name').addClass('error');
				$('#con_name').focus();
				return false;
			}
			else if(contactname == ' '){
				$('#con_name').addClass('error')
				$('#con_name').focus();
				return false;
			}
			else if(!phexp.test(contactno)){
				$('#con_name').removeClass('error')
				$('#con_no').addClass('error');
				return false;
			}
			
			else if(contactno == 'Contact Number *'){
				$('#con_no').addClass('error');
				return false;
			}
			else if(conemailid == 'Email Address *'){
				$('#con_no').removeClass('error');
				$('#con_email').addClass('error');
				return false;
			}
			else if(!emailpattern.test(conemailid)){
				$('#con_email').addClass('error');
				return false;
			}
			else if(selectone == 'Country you belong to?'){
			$('#con_email').removeClass('error');
				$('#menulist').addClass('error');
				return false;
			}
			else if(selecttwo == 'Service Required'){
			$('#menulist').removeClass('error');
				$('#menulist_two').addClass('error');
				return false;
			}
				
		
	});
		});
		
	</script>

  </body>
