
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <title>EZNRI | Work With Us</title>
    <!-- CSS Files -->
       <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
<!--load amimate.css from CDN-->
   <!-- CSS Files -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link href="css/style.css" rel="stylesheet">
		<link type="text/css" href="css/animation.css" rel="stylesheet">
  </head>
<body><div class="loading"><p>Loading...</p></div>
<header> 
  <div id="header_top">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 htop clearfix">
				<div class="htop_left txtLft">
					<ul class="contacts">
						<li><p><span><img src="images/time.png" alt=""></span>Mon-Sat</p></li>
						<li><p><span><img src="images/phone.png" alt=""></span><a href="tel:9500068580">9500068580/20</a></p></li>
						<li><p><span><img src="images/mail.png" alt=""></span><a href="mailto:Contact@eznri.com">contact@eznri.com</a></p></li>
					</ul>
				</div>
				<div class="htop_right txtRgt">
					<ul class="social_icons">
						<li><a href="https://www.facebook.com/eznri/?fref=ts" target="_blank"><i class="fa fa-facebook"></i></a></li>
						<li><a href="https://twitter.com/EZ_NRI" target="_blank"><i class="fa fa-twitter"></i></a></li>
						<li><a href="https://plus.google.com/u/0/102742721967205623609" target="_blank"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
  </div> 
<nav class="navbar navbar-default navbar-fixed-top clearfix" role="navigation">
 <!-- Header Top -->
	
  <div class="container clearfix">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-main"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand txtLft" href="index.html"><img src="images/eznri_logo.png" alt=""></a> </div>
    <div class="collapse navbar-collapse" id="navbar-collapse-main">
     <ul class="nav navbar-nav txtRgt">
        <li><a class="about_us" href="about_us.html"><i class="fa fa-info-circle menu_fontawe"></i>About Us</a></li>
        <li><a class="services" href="services.html"><i class="fa fa-cogs menu_fontawe"></i>Services</a></li>
        <li><a class="careers" href="careers.html"><i class="fa fa-briefcase menu_fontawe work_fontawe"></i>Work With Us</a></li>
      <li><a class="testimonials" href="testimonials.html"><i class="fa fa-file-text menu_fontawe_tetsti"></i>Testimonials</a></li>
		 <li><a class="contact_us" href="contactus.html"><i class="fa fa-location-arrow menu_fontawe_cont"></i>Contact Us</a></li>
      </ul>
    </div>
  </div>
</nav>
<!-- Navbar End --->
</header>
 <!-- Main Section Start -->
 <div class="wrapper">
			<!-- Careers start -->
				<section id="careers_sec">
					<div class="container">
						<div class="row clearfix">
							<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 career_para">
									<h1 class="home_page_heading text-left animated animation-visible fadeInLeftNow nocsstransition">Work With Us</h1>
									<p class="text-left animated animation-visible fadeInRightNow nocsstransition">We are looking out volunteers across India on a freelance basis to ensure that we get the work down on the specific area with giving clear updates on the proceedings on time. Remuneration would be based on the project assignment and duration.</p>
							</div>
						</div>
						<div class="row">
							<h1 class="career_heading animated animation-visible fadeInLeftNow nocsstransition">Become a Volunteer?</h1>
							<p class="career_p animated animation-visible fadeInRightNow nocsstransition">Fill in the below form for us to be in touch with you</p>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix">
								
								<div class="form_conainter">
									 <form  class="careers_frm"action="careers2.php" method="post">
										<span class="animated animation-visible fadeInDownNow nocsstransition"><input type="text" name="name" placeholder="Name" class="careers_input"></span>
										<span class="animated animation-visible fadeInDownNow nocsstransition"><input type="text" name="number" placeholder="Contact Number" class="careers_input"></span>
										<span class="animated animation-visible fadeInDownNow nocsstransition"><input type="text" name="email" placeholder="Email id" class="careers_input"></span>
										<span class="animated animation-visible fadeInDownNow nocsstransition"><input type="text" name="address" placeholder="Residential Address" class="careers_input"></span>
										<span class="animated animation-visible fadeInDownNow nocsstransition"><input type="text" name="area" placeholder="Area" class="careers_input"></span>
										<span class="animated animation-visible fadeInDownNow nocsstransition"><input type="text" name="city" placeholder="City" class="careers_input"></span>
										<span class="animated animation-visible fadeInDownNow nocsstransition"><input type="text" name="pincode" placeholder="Pincode" class="careers_input"></span>
										<span class="select_box animated animation-visible fadeInDownNow nocsstransition">
										   <span class="arrow"> <i class="fa fa-angle-down"></i></span>
										   <select class="careers_input" name="day" id="menulist">
												<option value="days">Available Days<br></option>
												<option value="mon">Monday<br></option><br>
												<option value="tue">Tuesday<br></option><br>
												<option value="wed">Wednesday<br></option><br>
												<option value="thursday">Thursday<br></option><br>
												<option value="friday">Friday<br></option><br>
										   </select>    
										</span>
										
										<span class="animated animation-visible fadeInDownNow nocsstransition"><input type="submit" value="Send" class="sendbtn careers_input"></span>
									 </form>
								</div>
							</div>
						</div>
						
					</div>	
				</section>
		<!-- Carrers End -->
 </div> <!-- Main Section End -->
 <!-- Footer Start -->
 <footer id="footer_menu">
	<div class="footer_section">
		<div class="container">
			<div class="row clearfix">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix padzero">
							<div class="ftr_content">
								<h2>Contact Details</h2>
								<div class="ftr_contact">
									<ul class="ul_left">
										<li class="clearfix"><span class="fa_map"><i class="fa fa-map-marker"></i></span><span class="con_address">33/18, 1st Floor, Anna Main Road, MGR Nagar, Chennai – 78</span></li>
										<li class="clearfix"><span class="fa_map"><i class="fa fa-phone"></i></span><a href="tel:9500068580" class="con phone">9500068580/20</a></li>
										<li class="clearfix"><span class="fa_map"><i class="fa fa-envelope-o"></i></span><a href="mailto:Contact@eznri.com" class="con mail" >contact@eznri.com</a></li>
									</ul>
									<ul class="usefullinks">
										<h2>Useful Links</h2>
										<li><a href="about_us.html">About Us</a></li>
										<li><a href="services.html">Services</a></li>
										<li><a href="careers.html">Work With Us</a></li>
										<li><a href="testimonials.html">Testimonials</a></li>
										<li><a href="contactus.html">Contact Us</a></li>
									</ul>
									<ul class="socials text-center">
										<h2>Follow Us</h2>
										<li><a href="https://www.facebook.com/eznri/?fref=ts" target="_blank"><i class="fa fa-facebook"></i></a></li>
										<li><a href="https://twitter.com/EZ_NRI" target="_blank"><i class="fa fa-twitter"></i></a></li>
										<li><a href="https://plus.google.com/u/0/102742721967205623609" target="_blank"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
					
					
				</div>
			</div>
			<div class="copyrights">
				
				<hr>
				<p class="text-center">Copyright &copy; 2016, All Right Reserved, <span class="godigitell"><a href="http://godigitell.com/" target="_blank">Godigitell.com</a></span></p>
			</div>
		</div>	
	</div>
 </footer> <!-- Footer End -->
 <a href="#" class="scrollToTop"><i class="fa fa-angle-up"></i></a>
   <!-- JS Files -->
	<script src="js/plugins.js"></script>
	<script src="js/gridlayout.js"></script> 
	<script src="js/jquery.light-carousel.js"></script> 
	<script src="js/modernizr.custom.js"></script> 
	<script src="js/jQueryRotateCompressed.js"></script>
	<script src="js/custom.js" ></script> 

</script>
 </body>
</html>
