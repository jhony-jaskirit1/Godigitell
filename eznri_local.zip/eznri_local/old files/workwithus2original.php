<?php 
include "connection.php";

$name = $_POST["name"];
$number = $_POST["number"];
$email = $_POST["email"];
$address = $_POST["address"];
$area = $_POST["area"];
$city = $_POST["city"];
$pincode = $_POST["pincode"];
$day = $_POST["day"];


 $name = mysqli_real_escape_string($con, $name);
 $number = mysqli_real_escape_string($con, $number);
 $email = mysqli_real_escape_string($con, $email);
 $address = mysqli_real_escape_string($con, $address);
 $area = mysqli_real_escape_string($con, $area);
 $city = mysqli_real_escape_string($con, $city);
 $pincode = mysqli_real_escape_string($con, $pincode);
 $day = mysqli_real_escape_string($con, $day);
 
  
$sql = "INSERT INTO `jaz_career` (`name`, `number`, `email`, `address`, `area`, `city`, `pincode`, `day`) VALUES ('$name', '$number', '$email', '$address', '$area', '$city', '$pincode', '$day')";
if(mysqli_query($con, $sql))  
{
}

$get = "SELECT * FROM `jaz_career`";
$value = $con->query($get);

if ($value->num_rows > 0) 
{
      while($datas = $value->fetch_assoc()) 
	  {
      	$name1 = $datas["name"];
		$address1 = $datas["address"];
		$email1 = $datas["email"];
		$number1 = $datas["number"];
		$area1 = $datas["area"];
		$day1 = $datas["day"];
		$city1 = $datas["city"];
		$pincode1 = $datas["pincode"];
      }	  
} 
$to = $email;
$from_name = "GoDigitell";
$from_email = "godigitell.com";
$subject = "Thanks for contacting Us";
$txt = "Thanks for contacting us, our executive will be in touch with you shortly. \r\n
Regards
GoDigitell Team";

//user mail
$subject = "Thanks for contacting Us";
$txt = "Thanks for contacting us, our executive will be in touch with you shortly. \r\n

Regards
GoDigitell Team";

$headers .= "From: ".$from_name."<".$from_email. ">\r\n" ;
$headers .= "MIME-Version: 1.0\r\n"; 
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n"; 
$headers .= "X-Priority: 1\r\n"; 

mail($to,$subject,$txt,$headers);

//admin mail

$to = $email;
$from_name = "GoDigitell";
$from_email = "sales@godigitell.com";

$subject = "User Contact Details:";

$txt1 = "An user shared the below information. \r\n\n";
$txt1 .= "Name : ".$name1." \r\n";
$txt1 .= "Contact No : ".$number ." \r\n";
$txt1 .= "Email : ".$email1." \r\n";
$txt1 .= "Address : ".$address1." \r\n";
$txt1 .= "Area : ".$area1." \r\n";
$txt1 .= "City  : ".$city1 ." \r\n";
$txt1 .= "Pincode  : ".$pincode1 ." ";
$txt1 .= "Day  : ".$day ." ";

$headers1 .= "From: ".$from_name."<".$from_email. ">\r\n" ;
//"CC: jhony.jaskirit@gmail.com";
$headers1 .= 'To: jhony.jaskirit@gmail.com' . "\r\n";

$headers1 .= "MIME-Version: 1.0\r\n"; 
$headers1 .= "Content-Type: text/html; charset=ISO-8859-1\r\n"; 
$headers1 .= "X-Priority: 1\r\n"; 
//$message =  "An user shared the below information:  <br>  <br>Name :$name1 <br>Phone:$number <br>Email	: $email1  <br>Address	:$address1 \r\n  <br>Area:$area1  <br>City	:$city1 <br>Pincode	:$pincode1 <br>Day:$day";

mail($to,$subject,$txt1,$headers1);
header('Location: http://godrive.co.in/eznri_local/thanku.html');
?>