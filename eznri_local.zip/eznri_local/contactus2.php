<?php 
include "connection.php";
  
$name = $_POST["name"];
$mobile = $_POST["mobile"];
$email = $_POST["email"];
$country = $_POST["country"];
$service = $_POST["service"];
$message = $_POST["message"];

 $name = mysqli_real_escape_string($con, $name);
 $number = mysqli_real_escape_string($con, $mobile);
 $email = mysqli_real_escape_string($con, $email);
 $country = mysqli_real_escape_string($con, $country);
 $service = mysqli_real_escape_string($con, $service);
 $message = mysqli_real_escape_string($con, $message);
 
$sql = "INSERT INTO `jaz_contactform` (`name`, `number`, `email`, `country`, `service`, `message`) VALUES ('$name', '$mobile', '$email', '$country', '$service', '$message')";
if(mysqli_query($con, $sql))  
{

}

$get = "SELECT * FROM `jaz_contactform`";
$value = $con->query($get);

if ($value->num_rows > 0) 
{
      while($datas = $value->fetch_assoc()) 
	  {
      	$name1 = $datas["name"];
		$number1 = $datas["number"];
		$email1 = $datas["email"];
		$country1 = $datas["country"];
		$service1 = $datas["service"];
		$message1 = $datas["message"];
      }	  
} 


$to = $email;
$from_name = "GoDigitell";
$from_email = "godigitell.com";

//user mail
$subject = "Thanks for contacting Us";
$txt = "Thanks for contacting us, our executive will be in touch with you shortly. \r\n

Regards
GoDigitell Team";

$headers .= "From: ".$from_name."<".$from_email. ">\r\n" ;
$headers .= "MIME-Version: 1.0\r\n"; 
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n"; 
$headers .= "X-Priority: 1\r\n"; 

mail($to,$subject,$txt,$headers);


//admin mail
$subject1 = "User Contact Details:";
$from_name1 = "GoDigitell";
$from_email1 = "godigitell.com";

$txt1 = "An user shared the below information. \r\n\n";
$txt1 .= "Name : ".$name1." \r\n";
$txt1 .= "Email : ".$email1." \r\n";
$txt1 .= "Contact No : ".$mobile ." \r\n";
$txt1 .= "Country : ".$country1." \r\n";
$txt1 .= "service  : ".$service ." \r\n";
$txt1 .= "message  : ".$message1 ." <br>";

$headers1 = "From: ".$from_name1."<".$from_email1. ">\r\n" ;
$headers1 .= 'To: jhony.jaskirit@gmail.com' . "\r\n";
//$headers .= 'Cc: jhony.jaskirit@gmail.com' . "\r\n";
$headers1 .= "MIME-Version: 1.0\r\n"; 
$headers1 .= "Content-Type: text/html; charset=ISO-8859-1\r\n"; 
$headers1 .= "X-Priority: 1\r\n";

mail($to,$subject1,$txt1,$headers1);

header('Location: http://godrive.co.in/eznri_local/thanku.html');
?>